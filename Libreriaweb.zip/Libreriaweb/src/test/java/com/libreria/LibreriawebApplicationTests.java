package com.libreria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibreriawebApplicationTests {

	@Test
	void contextLoads() {
	}

}
